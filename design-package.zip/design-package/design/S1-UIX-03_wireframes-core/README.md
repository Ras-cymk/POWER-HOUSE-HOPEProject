# S1-UIX-03 — Wireframes: main page, User Management list and Rights dialog

Put the exports here:

- `S1-UIX-03_wireframe_main-page.png`
- `S1-UIX-03_wireframe_user-management-list.png`
- `S1-UIX-03_wireframe_rights-dialog.png`

Figma source: paste link here.
