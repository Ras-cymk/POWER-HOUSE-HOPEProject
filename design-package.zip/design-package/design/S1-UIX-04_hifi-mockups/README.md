# S1-UIX-04 — Hi-fi mockups: login, register, main page, User Management, Rights dialog

Put the exports here (desktop @2x):

- `S1-UIX-04_hifi_login.png`
- `S1-UIX-04_hifi_register.png`
- `S1-UIX-04_hifi_main-page.png`
- `S1-UIX-04_hifi_user-management.png`
- `S1-UIX-04_hifi_rights-dialog.png`

These mockups are what the devs build from (S1-DEV-03 to DEV-08). Export from the final approved Figma frame only.

Figma source: paste link here.
