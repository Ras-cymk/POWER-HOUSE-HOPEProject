# HOPE ERP — Sprint 1 UI/UX Design Deliverables

This folder holds all UI/UX deliverables for Sprint 1. Task IDs match the sprint plan.

| Task | Deliverable | Folder | Duration |
|---|---|---|---|
| S1-UIX-01 | Design system: colors, typography, core components | `S1-UIX-01_design-system/` | 2 d |
| S1-UIX-02 | Wireframes: login, register, set/reset password | `S1-UIX-02_wireframes-auth/` | 3 d |
| S1-UIX-03 | Wireframes: main page, User Management list and Rights dialog | `S1-UIX-03_wireframes-core/` | 4 d |
| S1-UIX-04 | Hi-fi mockups: login, register, main page, User Management, Rights dialog | `S1-UIX-04_hifi-mockups/` | 6 d |

## How this folder works

- The editable **source of truth is Figma** (or whatever design tool we use). GitHub holds the **exports** (PNG @2x, SVG for icons/logos) so devs always have a versioned snapshot next to the code.
- Paste the Figma file link in the list below and in each task folder's README.
- Task status is tracked in **GitHub Issues** (see `github-issues.md`), not in this table.
- File naming: `<task-id>_<screen>_v<version>.png` — example: `S1-UIX-04_hifi_user-management_v2.png`.

## Design sources

| Task | Figma link |
|---|---|
| S1-UIX-01 Design system | paste link |
| S1-UIX-02 Wireframes (auth) | paste link |
| S1-UIX-03 Wireframes (core) | paste link |
| S1-UIX-04 Hi-fi mockups | paste link |
