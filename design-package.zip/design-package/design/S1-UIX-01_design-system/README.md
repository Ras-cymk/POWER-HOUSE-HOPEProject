# S1-UIX-01 — Design system: colors, typography, core components

Put the exports here:

- `S1-UIX-01_colors.png` — full color palette (primary / secondary / semantic states)
- `S1-UIX-01_typography.png` — type scale (headings, body, captions)
- `S1-UIX-01_components.png` — core component sheet (buttons, inputs, badges, table, dialog)

Icons and logos: also drop SVG versions next to the PNGs.

Figma source: paste link here.
