# S1-UIX-02 — Wireframes: login, register, set/reset password

Put the exports here:

- `S1-UIX-02_wireframe_login.png`
- `S1-UIX-02_wireframe_register.png`
- `S1-UIX-02_wireframe_set-password.png`
- `S1-UIX-02_wireframe_reset-password.png`

Figma source: paste link here.
